# PYRAMID

Hi! Wellcome to PYRAMID, the game where you have to create words using the letters given to create a... Yes you guessed it, a pyramid.

Let me introduce myself. My name is Víctor Morant and i'm a web developer. I just finished an app development course and this is actually my first project. I know I have to improve my coding skills and that is why I'm going to keep improving this application.

You are free to get anything you want from this apps code. And if you are interested, the languages I use are JavaScript, html, json and css.

## Contact

Here is my email in case you have any questions: victormorantf@gmail.com
