#CONTRIBUTIONS

I haven't thought about the possibility that anyone would want to make any contribution to my code. But if you are interested, just contact me at victormorantf@gmail.com
